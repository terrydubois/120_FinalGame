// define menu state and methods
var MainMenu = function(game) {};
MainMenu.prototype = {
	preload: function() {
		console.log('MainMenu: preload');
	
	},
	create: function() {
		console.log('MainMenu: create');

	},
	update: function() {

	}
}