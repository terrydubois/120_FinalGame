In BPM, you collect Stars to unlock new modes. There are three modes in total,
in addition to our Practice mode. We encourage whoever grades this project to
try and unlock all the modes manually, but we understand if you want to skip
the process and play every mode sooner for grading purposes.

So, we have included the "cheat code" CTRL+ALT+Q to give as many stars as they want.
This cheat code can be entered from the Main Menu or any Gameplay Mode.